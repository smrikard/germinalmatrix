package retina;

import repast.simphony.space.grid.Grid;

public class Pericyte {

	private Grid<Object> grid;
	private int cellCount;
	
	public Pericyte(Grid<Object> grid) {
		this.grid = grid;
	}
	
	public void setPcCount(int PcCount) {
		this.cellCount = PcCount;
	}
	
	public int getPcCount(){
		return cellCount;
	}


}
