package retina;

import repast.simphony.space.grid.Grid;

public class EndothelialCell {
	
	private Grid<Object> grid;
	private int cellCount;
	
	public EndothelialCell(Grid<Object> grid) {
		this.grid = grid;
	}
	
	public void setEcCount(int EcCount) {
		this.cellCount = EcCount;
	}
	
	public int getEcCount(){
		return cellCount;
	}

}
