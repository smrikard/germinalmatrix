package retina;


import java.awt.Color;

import repast.simphony.valueLayer.ValueLayer;
import repast.simphony.visualizationOGL2D.ValueLayerStyleOGL;

public class GradientStyle implements ValueLayerStyleOGL {
	
	protected ValueLayer layer;
	
	public void init(ValueLayer layer) {
		this.layer = layer;
	}
	
	public float getCellSize() {
		return 15.0f;
	}
	
	public Color getColor(double... coordinates) {
		
		double scale = layer.get(coordinates)/3.35;
		
		return Color.getHSBColor((float)0.4, (float)scale, 1);
	}

}
