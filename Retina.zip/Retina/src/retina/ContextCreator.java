package retina;

import repast.simphony.context.Context;
import repast.simphony.dataLoader.ContextBuilder;

public class ContextCreator implements ContextBuilder <Object> {

	public static Context<Object> context;
	
	public Context<Object> build(Context<Object> context) {
		AngioContextBuilder angioContext = new AngioContextBuilder();
		context.addSubContext(angioContext);
		context.add(angioContext);
		context.setId("Retina");
		ContextCreator.context = context;
		
		return context;
	}
}
