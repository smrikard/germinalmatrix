package retina;

import java.awt.Color;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.scene.VSpatial;

public class ECstyle extends DefaultStyleOGL2D{

	 public Color getColor(Object agent) {
		EndothelialCell thisCell = (EndothelialCell)agent;
		int green = thisCell.getEcCount()*8;
		int blue = thisCell.getEcCount()*8;
		
	    return new Color(255, green, blue); // shades of red
	  }
	
	public float getCellSize() {
		return 15.0f;
	}
	
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
	    if (spatial == null) {
	      spatial = shapeFactory.createRectangle(15, 15);
	    }
	    return spatial;
	  }

}
