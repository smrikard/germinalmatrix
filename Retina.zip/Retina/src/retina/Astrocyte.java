package retina;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;

public class Astrocyte {
	
	private Grid<Object> grid;
	private String name = "Astrocyte";
	public int id;
	
	public Astrocyte(Grid<Object> grid) {
		this.grid = grid;
	}

	public static void main(String[] args) {

	}
	

}
