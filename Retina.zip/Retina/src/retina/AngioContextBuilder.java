package retina;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


import repast.simphony.context.Context;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.util.ContextUtils;
import repast.simphony.valueLayer.GridValueLayer;
import repast.simphony.valueLayer.IGridValueLayer;
import repast.simphony.valueLayer.ValueLayerDiffuser;

public class AngioContextBuilder implements ContextBuilder<Object> {

	private ValueLayerDiffuser diffuser;
	private GridValueLayer vegf;
	
	@Override
	public Context build(Context<Object> context) {
		context.setId("Retina");
		
		Parameters params = RunEnvironment.getInstance().getParameters();

		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Object> grid = gridFactory.createGrid("grid", context,
				new GridBuilderParameters<Object>(new WrapAroundBorders(),
						new SimpleGridAdder<Object>(), true, 135, 128));
		
		//Determine from parameter settings whether to load or make astrocyte template
		boolean load = (Boolean) params.getBoolean("loadTemplate");
		boolean make = (Boolean) params.getBoolean("makeTemplate");
		boolean uniform = (Boolean) params.getBoolean("uniformVEGF");
		boolean radial = (Boolean) params.getBoolean("radialVEGF");
		
		if (make == true && load == true){
			System.out.println("Error: User may only select either 'Load Template' OR 'Make Template'");
		} else if (load == true) {
			loadTemplate(grid, context);
			seedCellsBottom(grid, context);
		} else if (make == true) {
			makeTemplate(grid, context);
			seedCellsBottom(grid, context);
		} else if (uniform == true) {
			makeUniformGradient(grid, context);
			seedCellsBottom(grid, context);
		} else if (radial == true) {
			makeRadialGradient(grid, context);
			seedCellsMiddle(grid, context);
		} else {
			System.out.println("Error: User must select either 'Load Template' or 'Make Template'");
		}
		
		return context;
	}
	
	private void makeUniformGradient(Grid<Object> grid, Context<Object> context){

		vegf = new GridValueLayer("Vegf", true, new WrapAroundBorders(), 135, 128);
		context.addValueLayer(vegf);
		
		for (int i = 0; i<128; i++){
			for (int j = 0; j<135; j++){
				vegf.set(i*0.025, j, i);
			}
		}

	}
	
	private void makeRadialGradient(Grid<Object> grid, Context<Object> context){
		
		vegf = new GridValueLayer("Vegf", true, new WrapAroundBorders(), 135, 128);
		context.addValueLayer(vegf);
		
		for (int i = 0; i<128; i++){
			for (int j = 0; j<135; j++){
				vegf.set(Math.sqrt(Math.pow(i-64,2) + Math.pow(j-67,2))*0.036, j, i);
			}
		}
		
	}
	
	private void makeTemplate(Grid<Object> grid, Context<Object> context) {
		Parameters params = RunEnvironment.getInstance().getParameters();
		
		vegf = new GridValueLayer("Vegf", true, new WrapAroundBorders(), 135, 128);
		context.addValueLayer(vegf);
		
		//Create astrocytes = number of starting branches at random x, y = 0
		int branches = (Integer) params.getValue("startingBranches");
		
		List<GridPoint> reproducing = new ArrayList<GridPoint>();
		
		for (int k=0; k < branches; k++) {
			Astrocyte astrocyte = new Astrocyte(grid);
			context.add(astrocyte);
			grid.moveTo(astrocyte, RandomHelper.nextIntFromTo(0, 135), 0);
			GridPoint pt = grid.getLocation(astrocyte);
			reproducing.add(new GridPoint(pt.getX(),pt.getY()));
			vegf.set(3, pt.getX(),pt.getY());
		}	
		
		//findEmptySites().isEmpty()
		//for (int i = 0; i < reproducing.size(); i++) {
		//	reproduce(grid, context);
		//}
			
		
	}
	
	private void loadTemplate(Grid<Object> grid, Context<Object> context) {
		
		//Ask user for the template to use for astrocyte network
		Scanner reader = new Scanner(System.in);
		System.out.println("Which template would you like to load? Enter a number 1-6: ");
		int template = reader.nextInt();
		System.out.println("You have loaded template number: " + template);
		reader.close();
				
		String templateFile = "template_" + template + ".txt";

		File textFile = new File(templateFile);
		Scanner in = null;
		BufferedReader reader2 = null;
		int lines = 0;
				
		try {
			in = new Scanner(textFile);
			reader2 = new BufferedReader(new FileReader(templateFile));
					
			while (reader2.readLine() != null) {
				lines++;
			}
			reader2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		System.out.println("File contains " + lines + " lines");

		int[] xcor;
		xcor = new int[lines];

		int[] ycor;
		ycor = new int[lines];

		int count = 0;
		int position = 0;
		int xadd = 67;
		int yadd = 64;
		
		while (in.hasNextInt()) {
			int value = in.nextInt();

			int remain = count % 2;

			if (remain == 0) {
				xcor[position] = value + xadd;
			} else {
				ycor[position] = value + yadd;
				position++;
			}
					
			count++;
		}
		
		System.out.println("First x coord is: " + xcor[0]);
		System.out.println("First y coord is: " + ycor[0]);
		in.close();
		
		vegf = new GridValueLayer("Vegf", true, new WrapAroundBorders(), 135, 128);
		context.addValueLayer(vegf);
		diffuser = new ValueLayerDiffuser((IGridValueLayer)vegf, 1.0, 0.4, false);
		
		//create astrocyte objects and place them at specified x and y coordinates
		int astrocyteCount = lines;
		for (int i = 0; i<astrocyteCount; i++) {
			Astrocyte astrocyte = new Astrocyte(grid);
			context.add(astrocyte);
			grid.moveTo(astrocyte, xcor[i], ycor[i]);
			vegf.set(1, xcor[i], ycor[i]);
		}
		
		for (int n = 0; n<5; n++){
			for (int j = 0; j<astrocyteCount; j++) {
				double val = vegf.get(xcor[j], ycor[j]);
				vegf.set(val+1, xcor[j], ycor[j]);
			}
			for (int i = 0; i<5; i++){
				diffuser.diffuse();
			}	
		}
		
	}

	private void seedCellsBottom(Grid<Object> grid, Context<Object> context){
		Parameters params = RunEnvironment.getInstance().getParameters();
		boolean EConly = (Boolean) params.getBoolean("startEC");
		boolean sparseEC = (Boolean) params.getBoolean("startSparse");
		boolean ECandPC = (Boolean) params.getBoolean("startECandPC");
		
		if (EConly == true){
			
			int EcCount = 1;
			
			for (int a = 12; a<125; a = a+20){
				for (int b = 5; b<26; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 22; a<115; a = a+20){
				for (int b = 10; b<21; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}

		}
		
		if (ECandPC == true){
			
			int EcCount = 1;
			int PcCount = 1;
			
			for (int a = 12; a<125; a = a+20){
				for (int b = 5; b<26; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 22; a<115; a = a+20){
				for (int b = 10; b<21; b = b+10){
					
					int chance = (int)(100*Math.random());
					
					if (chance < 25){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
					}
					
					else {
						makePC(grid, context, PcCount, a, b);
						PcCount++;
					}
				}
			}
		}
		
		if (sparseEC == true){
			
			int EcCount = 1;
			
			for (int a = 12; a<125; a = a+20){
				for (int b = 5; b<26; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 22; a<115; a = a+20){
				for (int b = 10; b<21; b = b+10){
					
					int chance = (int)(100*Math.random());
					
					if (chance < 25){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
					}

				}
			}

		}
	}
	
	private void seedCellsMiddle(Grid<Object> grid, Context<Object> context){
		Parameters params = RunEnvironment.getInstance().getParameters();
		boolean EConly = (Boolean) params.getBoolean("startEC");
		boolean sparseEC = (Boolean) params.getBoolean("startSparse");
		boolean ECandPC = (Boolean) params.getBoolean("startECandPC");
		
		if (EConly == true){
			
			int EcCount = 1;
			
			for (int a = 42; a<83; a = a+20){
				for (int b = 39; b<80; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 52; a<73; a = a+20){
				for (int b = 44; b<75; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 32; a<93; a = a+60){
				for (int b = 54; b<65; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			

		}
		
		if (ECandPC == true){
			
			int EcCount = 1;
			int PcCount = 1;
			
			for (int a = 42; a<83; a = a+20){
				for (int b = 39; b<80; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 52; a<73; a = a+20){
				for (int b = 44; b<75; b = b+10){
					
					int chance = (int)(100*Math.random());
					
					if (chance < 25){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
					}
					
					else {
						makePC(grid, context, PcCount, a, b);
						PcCount++;
					}
				}
			}
			
			for (int a = 32; a<93; a = a+60){
				for (int b = 54; b<65; b = b+10){
					
					int chance = (int)(100*Math.random());
					
					if (chance < 25){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
					}
					
					else {
						makePC(grid, context, PcCount, a, b);
						PcCount++;
					}
				}
			}
		}
		
		if (sparseEC == true){
			
			int EcCount = 1;
			
			for (int a = 42; a<83; a = a+20){
				for (int b = 39; b<80; b = b+10){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
				}
			}
			
			for (int a = 52; a<73; a = a+20){
				for (int b = 44; b<75; b = b+10){
					
					int chance = (int)(100*Math.random());
					
					if (chance < 25){
					makeEC(grid, context, EcCount, a, b);
					EcCount++;
					}
				}
			}
		
		for (int a = 32; a<93; a = a+60){
			for (int b = 54; b<65; b = b+10){
				
				int chance = (int)(100*Math.random());
				
				if (chance < 25){
				makeEC(grid, context, EcCount, a, b);
				EcCount++;
				}

			}
		}

		}
	}
	
	private void makeEC(Grid<Object> grid, Context<Object> context, int cellCount, int a, int b){
		for (int i = a; i<(a+10); i++) {
			for (int j = b; j<(b+10); j++){
				EndothelialCell EC = new EndothelialCell(grid);
				context.add(EC);
				EC.setEcCount(cellCount);
				grid.moveTo(EC, i, j);
			}
		}
	}
	
	private void makePC(Grid<Object> grid, Context<Object> context, int cellCount, int a, int b){
		for (int i = a; i<(a+10); i++) {
			for (int j = b; j<(b+10); j++){
				Pericyte PC = new Pericyte(grid);
				context.add(PC);
				PC.setPcCount(cellCount);
				grid.moveTo(PC, i, j);
			}
		}
	}
	
	private void reproduce(Grid<Object> grid, Context<Object> context){		
	
		Astrocyte astrocyte = new Astrocyte(grid);	
		context.add(astrocyte);
		
		List<GridPoint> neighbors = findNeighbors();
		
		// TODO add Grid.moveTo(Object o, GridPoint pt) to Repast API
		if (neighbors.size() > 0) {
			grid.moveTo(astrocyte, neighbors.get(0).getX(), neighbors.get(0).getY());
		}
	}
	
	//Provides a list of adjacent sites in the cell's Moore 
	//neighborhood (excludes the 3 cells below to create forward movement).  
	//The list of sites is shuffled.
	
	private List<GridPoint> findNeighbors(){
		List<GridPoint> neighbors = new ArrayList<GridPoint>();
		Context context = ContextUtils.getContext(this);
		Grid grid = (Grid)context.getProjection("Grid");
		GridPoint pt = grid.getLocation(this);
		
		// Find Moore neighbors (excluding 3 in bottom row)
		neighbors.add(new GridPoint(pt.getX()-1,pt.getY()+1));
		neighbors.add(new GridPoint(pt.getX(),pt.getY()+1));
		neighbors.add(new GridPoint(pt.getX()+1,pt.getY()+1));
		neighbors.add(new GridPoint(pt.getX()+1,pt.getY()));
		neighbors.add(new GridPoint(pt.getX()-1,pt.getY()));
		
		Collections.shuffle(neighbors);
		
		return neighbors;
	}
}

