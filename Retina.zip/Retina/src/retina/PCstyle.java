package retina;

import java.awt.Color;

import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;
import saf.v3d.scene.VSpatial;

public class PCstyle extends DefaultStyleOGL2D{

	@Override
	 public Color getColor(Object agent) {
		Pericyte thisCell = (Pericyte)agent;
		int green = thisCell.getPcCount()*25;
	    return new Color(0, green, 255); // shades of blue
	  }
	
	public float getCellSize() {
		return 15.0f;
	}
	
	public VSpatial getVSpatial(Object agent, VSpatial spatial) {
	    if (spatial == null) {
	      spatial = shapeFactory.createRectangle(15, 15);
	    }
	    return spatial;
	  }

}
