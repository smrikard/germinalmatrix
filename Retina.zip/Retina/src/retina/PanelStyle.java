package retina;

import javax.swing.JPanel;

import repast.simphony.userpanel.ui.UserPanelCreator;

public class PanelStyle implements UserPanelCreator {

	public static JPanel panel;
	public static int startingBranches;
	public static int branchProbability;
	public static int startingTemplate;
	public static String cellLayout;
	public static String startingLayout;

	public static int alpha;
	public static int beta;
	
	public JPanel createPanel() {
		JPanel panel = new JPanel();
		panel = PanelStyle.panel;
		return panel;
	}
	
	
}
